function setup() {
  // put setup code here
  createCanvas(400,300);
  background(200,200,200);
}

function draw() {
  // put drawing code here
  colorMode(RGB,255,255,255,1);

  stroke(255,255,255,1);

  noFill();

  beginShape();
  curveVertex(50,118)
  curveVertex(50,130);
  curveVertex(50,150);
  curveVertex(70,170);
  curveVertex(80,190);
  curveVertex(90,190);
  endShape();

  beginShape();
  curveVertex(150,240);
  curveVertex(150,255);
  curveVertex(150,275);
  curveVertex(170,295);
  curveVertex(180,315);
  curveVertex(190,315);
  endShape();

  beginShape();
  curveVertex(250,118);
  curveVertex(250,130);
  curveVertex(250,150);
  curveVertex(270,170);
  curveVertex(280,190);
  curveVertex(290,190);
  endShape();

  beginShape();
  curveVertex(350,240);
  curveVertex(350,255);
  curveVertex(350,275);
  curveVertex(370,295);
  curveVertex(380,315);
  curveVertex(390,315);
  endShape();

  noStroke();

  fill(230,0,0,0.1);
  ellipse(50,75,70,85);
  triangle(50,115,40,130,60,130);

  fill(0,230,0,0.1);
  ellipse(150,200,70,85);
  triangle(150,240,140,255,160,255);

  fill(0,0,230,0.1);
  ellipse(250,75,70,85);
  triangle(250,115,240,130,260,130);

  fill(255,105,180);
  ellipse(350,200,70,85);
  triangle(350,240,340,255,360,255);
}