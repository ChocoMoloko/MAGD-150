function setup() {
  // put setup code here
  createCanvas(850,500);
  background(0,0,0);
}

function draw() {
  // put drawing code here

  // moon
  strokeWeight(1)
  noFill(220,220,220)
  stroke(255,255,255)
  circle(250,200,250)
  strokeWeight(5)
  strokeCap(SQUARE)
  line(200,100,200,300)
  line(144,150,144,250)
  line(172,120,172,270)
  strokeCap(ROUND)
  strokeJoin(ROUND)
  beginShape()
  vertex(275,150)
  vertex(325,200)
  vertex(275,250)
  endShape()

  //stars
  strokeWeight(5)
  point(356,456)
  point(123,367)
  point(800,236)
  point(56,121)
  point(489,444)
  point(456,250)
  point(632,123)
  point(700,345)
  point(56,121)
  point(399,18)
}