function setup() {
  // put setup code here
  createCanvas(600,600);
}
  

function draw() {

	colorMode(RGB,255,255,255,1);

	let a = mouseX;
	let b = mouseY;
    let c = pmouseX;
    let d = pmouseY;

	background(200);
	frameRate(60);

	line(0,b,600,b);
	line(a,0,a,600);

	fill(255,0,0);
	circle(c, d, 30);

	let GCSize = 30
	let GCLoc = 30

	fill(0,255,0);
	circle(GCLoc,GCLoc,GCSize);
	circle(GCLoc * 2.2,GCLoc * 2.2, pow(GCSize,1.2));
	circle(GCLoc * 4.4,GCLoc * 4.4, pow(GCSize,1.4));

	let BCSize = 120
	let BCLoc = 525

	fill(0,0,255);
	ellipse(BCLoc,BCLoc,BCSize,BCSize);
	ellipse(BCLoc/1.15,BCLoc/1.15,sqrt(BCSize*25),sqrt(BCSize*25));
	ellipse(BCLoc/1.25,BCLoc/1.25,sqrt(BCSize*10),sqrt(BCSize*10));
  // put drawing code here
}